<template>
    <div>
        <div class="pb-1">
            <router-link :to="{name: 'user.create'}" class="btn btn-success">Create</router-link>
        </div>
        <UsersTable
            :items="users"
            :headers="headers"
            :search="search"
            @deleteUser = "deleteUser">
        </UsersTable>
    </div>
</template>

<script>
    import UsersTable from "../tables/UsersTable";
    export default {
        name: "Users",
        components:{
          UsersTable,
        },
        data () {
            return {
                search: '',
                headers: [
                    { text: 'Name', align: 'left', sortable: false, value: 'name' },
                    { text: 'Surname', value: 'surname' },
                    { text: 'Email', value: 'email' },
                    { text: 'Phone', value: 'phone' },
                    { text: 'Cover Photo' , value : 'cover_photo'},
                    { text: 'Status', value: 'status' },
                    { text: 'Gender', value: 'gender' },
                    { text:'Actions', value:'action',align: 'center'}
                ],
                users: []
            }
        },
        mounted() {
            this.fetchUsers();
        },
        methods:{
            fetchUsers(page = 1){
                this.axios.get('/users?page='+page)
                    .then(response => (
                        this.users = response.data.data
                    ))
                    .catch(error => console.log(error.response));
            },
            deleteUser(userId){
                this.axios.delete(`/users/${userId}`)
                    .then(response => {
                        let index = this.users.map(user => user.id).indexOf(index); // find index of your object
                        this.users.splice(index, 1)
                    })
                    .catch(error => {console.log(error.response)})
            }
        }
    }
</script>

<style scoped>

</style>
