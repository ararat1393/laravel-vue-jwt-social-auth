<template>
    <section class="section-main">
        <div class="content-main">
            <router-view></router-view>
        </div>
    </section>
</template>

<script>
    export default {
        name: "Section"
    }
</script>

<style scoped>

</style>
