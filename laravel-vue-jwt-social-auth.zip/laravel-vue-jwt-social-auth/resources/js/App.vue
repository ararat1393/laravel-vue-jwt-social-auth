<template>
    <div v-if="!$auth.ready()" class="text-center">
        <img src="https://thumbs.gfycat.com/SimilarPlumpBarasingha-small.gif" alt="">
    </div>
    <div v-else="$auth.ready()">
<!--        <UnauthorizedMenu v-if="!$auth.check()"></UnauthorizedMenu>-->
<!--        <AdminMenu v-else-if="$auth.check('-1')"></AdminMenu>-->
<!--        <UserMenu v-else-if="$auth.check('0')"></UserMenu>-->
        <!--    dinamic components-->
        <component :is = "loadComponent"></component>
    </div>
</template>
<script>
    import AdminMenu from './components/admin/Menu.vue';
    import UserMenu from './components/user/Menu.vue';
    import UnauthorizedMenu from './components/unauthorized/Menu.vue';

    export default {
        name: "App",
        methods: {
        },
        computed:{
          loadComponent(){
              if(!this.$auth.check() ){
                  return 'UnauthorizedMenu';
              }
              if( this.$auth.check('0') ){
                  return 'UserMenu';
              }
              if( this.$auth.check('-1') ){
                  return 'AdminMenu';
              }
          }
        },
        beforeCreate() {
            if( window.social ){
                if( window.social.user ){
                    this.$auth.login({
                        data: {
                            email: window.social.user.email,
                            password: 'a123456'
                        },
                        rememberMe: true,
                        fetchUser: true
                    })
                }
            }
        },
        components: {
            AdminMenu,
            UserMenu,
            UnauthorizedMenu
        },
    }

</script>

<style scoped>

</style>
