
const providers = {
    github: {
        clientId: '',
        redirectUri: '/auth/github/callback' // Your client app URL
    },
    facebook: {
        clientId: '',
        redirectUri: '/auth/facebook/callback' // Your client app URL
    },
    google: {
        clientId: '',
        redirectUri: '/auth/google/callback' // Your client app URL
    },
    twitter: {
        clientId: '',
        redirectUri: '/auth/twitter/callback' // Your client app URL
    }
}
export default providers
