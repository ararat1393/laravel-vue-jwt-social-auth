@extends('backend.layouts.app')

@section('content')
    <div class="container">
        <h1 class="text-center">Backend</h1>
    </div>
@endsection
