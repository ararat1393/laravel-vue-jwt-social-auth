<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('status')): ?>
            <div class="alert alert-info">
                <span><?php echo e(Session::get('status')); ?></span>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.setting.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for=""> URL callback for Telegram Bot</label>
                <div class="input-group">
                    <div class="input-group-btn">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#" onClick="document.getElementById('url_callback_bot').value='<?php echo e(url('')); ?>'">Put Url</a>
                            <a class="dropdown-item" href="#" onClick="event.preventDefault();document.getElementById('setwebhook').submit()">Send Url </a>
                            <a class="dropdown-item" href="#" onClick="event.preventDefault();document.getElementById('getwebhookinfo').submit()">Get Info</a>
                        </div>
                    </div>
                    <input type="url" name='url_callback_bot' value="<?php echo e($url_callback_bot ?? ''); ?>" class="form-control" aria-label="Text input with dropdown button" id="url_callback_bot">
                </div>
            </div>
            <button class="btn btn-primary" type="submit">Save</button>
        </form>

            <form id="setwebhook" action="<?php echo e(route('admin.setting.setwebhook')); ?>" method="POST" style="display: none">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="url" value="<?php echo e($url_callback_bot ?? ''); ?>">
            </form>
            <form id="getwebhookinfo" action="<?php echo e(route('admin.setting.getwebhookinfo')); ?>" method="POST" style="display: none">
                <?php echo csrf_field(); ?>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\OSPanel\domains\laravel-vue\resources\views/backend/setting.blade.php ENDPATH**/ ?>