<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Backend</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\OSPanel\domains\laravel-vue\resources\views/backend/index.blade.php ENDPATH**/ ?>